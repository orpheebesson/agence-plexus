<img height="100" src="src/assets/img/logo_plexus.png" alt="Logo agence Plexus">

# :arrow_down: Installation

`git clone https://gitlab.univ-lr.fr/obesso01/agence-plexus.git`

# :warning: Dependencies

`npm install`

# :hammer_and_wrench: Gulp

Run the following command to launch the "watch" of your files :

`gulp`

Run the following command to trigger the build of assets for the production :

`gulp build`

More commands are availaible in the _gulpfile.js_.